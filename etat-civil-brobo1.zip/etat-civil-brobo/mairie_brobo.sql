-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 12 juin 2025 à 01:22
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mairie_brobo`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateurs`
--

CREATE TABLE `administrateurs` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `date_inscription` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `administrateurs`
--

INSERT INTO `administrateurs` (`id`, `nom`, `email`, `mot_de_passe`, `date_inscription`) VALUES
(1, 'keke', 'kekeadmin@gmail.com', '$2y$10$Vt9uuE8PTf79OlEDzwl5HO4H0kxH7U1j4DZSi0Xb0BwhfIGxltw/S', '2025-05-09 18:01:55');

-- --------------------------------------------------------

--
-- Structure de la table `citoyens`
--

CREATE TABLE `citoyens` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `date_inscription` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `citoyens`
--

INSERT INTO `citoyens` (`id`, `nom`, `prenom`, `email`, `mot_de_passe`, `date_inscription`) VALUES
(1, 'jean', 'marc', 'jeanmarc@gmail.com', '$2y$10$WdO2xaFufP4S14O/5A32N.l/./9cElbnTPvUWcUpVpmtyDJx.qecK', '2025-05-09 17:49:33'),
(2, 'JUNIOR', 'TOKPA', 'juniortokpa@gmail.com', '$2y$10$WAmRjG6NpEPu8Yk7Kz7ZyuJrxH6odp3A2LP41rXvNan5NE.GPE2.W', '2025-05-09 21:12:38'),
(3, 'Goulizan', 'Christ', 'stevenchrist857@gmail.com', '$2y$10$VN25sj/NEOzqZWuAL1/eE.AnXeyCx8hd1u6BsA9AZjBohIwRvxQtS', '2025-06-09 22:53:33'),
(4, 'Goulizan', 'Christ', 'christ@gmail.com', '$2y$10$lWIQVwWASZwct94VxS6ae.IjfDfV.CuzXRuTidGThkedzkqAJkVJe', '2025-06-10 09:12:25');

-- --------------------------------------------------------

--
-- Structure de la table `deces`
--

CREATE TABLE `deces` (
  `id` int(11) NOT NULL,
  `demande_id` int(11) NOT NULL,
  `nom_defunt` varchar(255) DEFAULT NULL,
  `nom_pere_defunt` varchar(255) DEFAULT NULL,
  `nom_mere_defunt` varchar(255) DEFAULT NULL,
  `date_deces` date DEFAULT NULL,
  `lieu_deces` varchar(255) DEFAULT NULL,
  `cause_deces` varchar(255) DEFAULT NULL,
  `piece_identite_defunt` text DEFAULT NULL,
  `piece_identite_declarant` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `deces`
--

INSERT INTO `deces` (`id`, `demande_id`, `nom_defunt`, `nom_pere_defunt`, `nom_mere_defunt`, `date_deces`, `lieu_deces`, `cause_deces`, `piece_identite_defunt`, `piece_identite_declarant`, `created_at`, `updated_at`) VALUES
(2, 19, 'vie', 'essais', 'uste', '2008-12-02', 'brobo', 'Maladie', NULL, NULL, '2025-06-11 11:14:15', '2025-06-11 11:14:15'),
(3, 41, 'ehjhgioqz', 'rphoirz', 'agiureah\"', '2099-08-20', 'brobo', 'hgqrhyr', '', '', '2025-06-11 11:17:51', '2025-06-11 11:17:51'),
(4, 43, 'sf<fwh', 'dwnwn', 'qfn', '4568-05-12', 'QBHEZ FB', 'hgqrhyr', '', '', '2025-06-11 11:30:11', '2025-06-11 11:30:11');

-- --------------------------------------------------------

--
-- Structure de la table `declarations`
--

CREATE TABLE `declarations` (
  `id` int(11) NOT NULL,
  `citoyen_id` int(11) NOT NULL,
  `type_acte` varchar(255) NOT NULL,
  `statut` enum('en_attente','accepte','rejete') DEFAULT 'en_attente',
  `date_declaration` datetime DEFAULT current_timestamp(),
  `fichiers` text DEFAULT NULL,
  `autre_donnees` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`autre_donnees`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `declarations`
--

INSERT INTO `declarations` (`id`, `citoyen_id`, `type_acte`, `statut`, `date_declaration`, `fichiers`, `autre_donnees`) VALUES
(1, 3, 'naissance', 'accepte', '2025-06-11 12:40:43', 'file_6849794b660c32.58421372.png,file_6849794b663932.45129511.png,file_6849794b666a00.62369991.png,file_6849794b6691e9.91031978.png', NULL),
(2, 3, 'reconnaissances', 'accepte', '2025-06-11 13:31:35', '', NULL),
(3, 3, 'reconnaissances', 'accepte', '2025-06-11 16:58:42', '', NULL),
(4, 3, 'naissance', 'accepte', '2025-06-11 22:22:53', 'file_684a01bd784bb0.14948819.png,file_684a01bd7cd450.62158173.png,file_684a01bd7d2a70.72575097.png,file_684a01bd7d8786.22909366.png', NULL),
(5, 3, 'reconnaissances', 'rejete', '2025-06-11 23:01:07', '', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `demandes_actes`
--

CREATE TABLE `demandes_actes` (
  `id` int(11) NOT NULL,
  `citoyen_id` int(11) NOT NULL,
  `type_acte` enum('naissance','mariage','deces') NOT NULL,
  `statut` enum('en_attente','accepte','rejete') DEFAULT 'en_attente',
  `date_demande` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `demandes_actes`
--

INSERT INTO `demandes_actes` (`id`, `citoyen_id`, `type_acte`, `statut`, `date_demande`) VALUES
(16, 3, 'mariage', 'accepte', '2025-06-10 12:47:34'),
(17, 3, 'mariage', 'accepte', '2025-06-10 12:47:37'),
(18, 3, 'mariage', 'accepte', '2025-06-10 12:50:06'),
(19, 3, 'deces', 'accepte', '2025-06-10 12:52:36'),
(29, 3, 'naissance', '', '2025-06-11 10:11:13'),
(30, 3, 'naissance', '', '2025-06-11 10:21:12'),
(31, 3, 'naissance', '', '2025-06-11 10:48:36'),
(32, 3, '', '', '2025-06-11 10:50:00'),
(33, 3, '', '', '2025-06-11 10:50:21'),
(34, 3, '', '', '2025-06-11 10:51:53'),
(35, 3, '', '', '2025-06-11 10:51:56'),
(36, 3, '', '', '2025-06-11 10:55:21'),
(37, 3, '', '', '2025-06-11 10:55:25'),
(38, 3, '', '', '2025-06-11 10:58:15'),
(39, 3, 'naissance', '', '2025-06-11 10:59:20'),
(40, 3, 'naissance', '', '2025-06-11 11:02:02'),
(41, 3, 'deces', '', '2025-06-11 11:17:51'),
(42, 3, 'naissance', 'accepte', '2025-06-11 11:21:58'),
(43, 3, 'deces', '', '2025-06-11 11:30:11'),
(44, 3, 'naissance', '', '2025-06-11 11:59:42');

-- --------------------------------------------------------

--
-- Structure de la table `mariages`
--

CREATE TABLE `mariages` (
  `id` int(11) NOT NULL,
  `demande_id` int(11) NOT NULL,
  `nom_epoux` varchar(255) DEFAULT NULL,
  `nom_epouse` varchar(255) DEFAULT NULL,
  `temoin_epoux` varchar(255) DEFAULT NULL,
  `temoin_epouse` varchar(255) DEFAULT NULL,
  `date_mariage` date DEFAULT NULL,
  `lieu_mariage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `mariages`
--

INSERT INTO `mariages` (`id`, `demande_id`, `nom_epoux`, `nom_epouse`, `temoin_epoux`, `temoin_epouse`, `date_mariage`, `lieu_mariage`) VALUES
(4, 18, 'junior', 'belle', 'bht', 'tey', '2012-02-02', 'brobo');

-- --------------------------------------------------------

--
-- Structure de la table `naissances`
--

CREATE TABLE `naissances` (
  `id` int(11) NOT NULL,
  `demande_id` int(11) NOT NULL,
  `nom_complet` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `nom_pere` varchar(255) DEFAULT NULL,
  `nom_mere` varchar(255) DEFAULT NULL,
  `lieu_naissance` varchar(255) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `pdfCnaissance` text DEFAULT NULL,
  `piece_identite_mere` text DEFAULT NULL,
  `piece_identite_pere` text DEFAULT NULL,
  `acte_mariage` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `naissances`
--

INSERT INTO `naissances` (`id`, `demande_id`, `nom_complet`, `sex`, `nom_pere`, `nom_mere`, `lieu_naissance`, `date_naissance`, `pdfCnaissance`, `piece_identite_mere`, `piece_identite_pere`, `acte_mariage`, `created_at`, `updated_at`) VALUES
(17, 30, 'Christ Goulizan', 'masculin', 'Christ', 'Goulizan', 'brobo', '2006-12-02', '', '', '', '', '2025-06-11 10:21:12', '2025-06-11 10:21:12'),
(18, 40, 'Christ Goulizan', 'masculin', 'Christ', 'Goulizan', 'brobo', '2012-01-14', '', '', '', '', '2025-06-11 11:02:02', '2025-06-11 11:02:02'),
(19, 42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-11 11:21:58', '2025-06-11 11:21:58'),
(20, 44, 'Christ Goulizan', 'masculin', 'Christ', 'Goulizan', 'brobo', '2004-05-05', '', '', '', '', '2025-06-11 11:59:42', '2025-06-11 11:59:42');

-- --------------------------------------------------------

--
-- Structure de la table `paiements`
--

CREATE TABLE `paiements` (
  `id` int(11) NOT NULL,
  `demande_id` int(11) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `operateur` enum('mtn','orange','moov','wave') DEFAULT NULL,
  `numero` varchar(20) DEFAULT NULL,
  `statut` enum('en_attente','effectue','echoue') DEFAULT 'en_attente',
  `date_paiement` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paiements`
--

INSERT INTO `paiements` (`id`, `demande_id`, `montant`, `operateur`, `numero`, `statut`, `date_paiement`) VALUES
(13, 19, 1000.00, 'mtn', '0515205214', 'effectue', '2025-06-10 14:12:09'),
(14, 18, 1000.00, 'mtn', '0515205214', 'effectue', '2025-06-10 14:15:18'),
(18, 17, 1000.00, 'mtn', '0515205214', 'effectue', '2025-06-10 14:17:06'),
(25, 42, 1000.00, 'mtn', '0515205214', 'effectue', '2025-06-11 11:22:57');

-- --------------------------------------------------------

--
-- Structure de la table `reconnaissances`
--

CREATE TABLE `reconnaissances` (
  `id` int(11) NOT NULL,
  `demande_id` int(11) NOT NULL,
  `piece_identite_pere` text DEFAULT NULL,
  `piece_identite_mere` text DEFAULT NULL,
  `extrait_enfant` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `reconnaissances`
--

INSERT INTO `reconnaissances` (`id`, `demande_id`, `piece_identite_pere`, `piece_identite_mere`, `extrait_enfant`, `created_at`, `updated_at`) VALUES
(1, 38, '', '', '', '2025-06-11 10:58:15', '2025-06-11 10:58:15');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `administrateurs`
--
ALTER TABLE `administrateurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `citoyens`
--
ALTER TABLE `citoyens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `deces`
--
ALTER TABLE `deces`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `demande_id` (`demande_id`);

--
-- Index pour la table `declarations`
--
ALTER TABLE `declarations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `citoyen_id` (`citoyen_id`);

--
-- Index pour la table `demandes_actes`
--
ALTER TABLE `demandes_actes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `citoyen_id` (`citoyen_id`);

--
-- Index pour la table `mariages`
--
ALTER TABLE `mariages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `demande_id` (`demande_id`);

--
-- Index pour la table `naissances`
--
ALTER TABLE `naissances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `demande_id` (`demande_id`);

--
-- Index pour la table `paiements`
--
ALTER TABLE `paiements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `demande_id` (`demande_id`);

--
-- Index pour la table `reconnaissances`
--
ALTER TABLE `reconnaissances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `demande_id` (`demande_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `administrateurs`
--
ALTER TABLE `administrateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `citoyens`
--
ALTER TABLE `citoyens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `deces`
--
ALTER TABLE `deces`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `declarations`
--
ALTER TABLE `declarations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `demandes_actes`
--
ALTER TABLE `demandes_actes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT pour la table `mariages`
--
ALTER TABLE `mariages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `naissances`
--
ALTER TABLE `naissances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `paiements`
--
ALTER TABLE `paiements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `reconnaissances`
--
ALTER TABLE `reconnaissances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `deces`
--
ALTER TABLE `deces`
  ADD CONSTRAINT `deces_ibfk_1` FOREIGN KEY (`demande_id`) REFERENCES `demandes_actes` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `declarations`
--
ALTER TABLE `declarations`
  ADD CONSTRAINT `declarations_ibfk_1` FOREIGN KEY (`citoyen_id`) REFERENCES `citoyens` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `demandes_actes`
--
ALTER TABLE `demandes_actes`
  ADD CONSTRAINT `demandes_actes_ibfk_1` FOREIGN KEY (`citoyen_id`) REFERENCES `citoyens` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `mariages`
--
ALTER TABLE `mariages`
  ADD CONSTRAINT `mariages_ibfk_1` FOREIGN KEY (`demande_id`) REFERENCES `demandes_actes` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `naissances`
--
ALTER TABLE `naissances`
  ADD CONSTRAINT `naissances_ibfk_1` FOREIGN KEY (`demande_id`) REFERENCES `demandes_actes` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `paiements`
--
ALTER TABLE `paiements`
  ADD CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`demande_id`) REFERENCES `demandes_actes` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reconnaissances`
--
ALTER TABLE `reconnaissances`
  ADD CONSTRAINT `reconnaissances_ibfk_1` FOREIGN KEY (`demande_id`) REFERENCES `demandes_actes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
