<?php
// Vérifiez si le fichier FPDF existe
if (!file_exists('../fpdf/fpdf.php')) {
    die('Le fichier fpdf.php est introuvable.');
}
require('../fpdf/fpdf.php');

$conn = new mysqli('localhost', 'root', '', 'mairie_brobo');

// Vérifiez la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

// Vérifiez si l'ID est passé et est un entier
if (!isset($_GET['demande_id']) || !is_numeric($_GET['demande_id'])) {
    die('ID de demande invalide.');
}

$id = (int)$_GET['demande_id'];

//Vérifie la demande et le paiement

$stmt = $conn->prepare("
    SELECT d.*, c.nom, c.prenom, p.statut AS paiment_statut
    FROM demandes_actes d
    JOIN citoyens c ON d.citoyen_id = c.id
    JOIN paiements p ON p.demande_id = d.id
    WHERE d.id = ? AND p.statut = 'effectue' AND d.statut = 'accepte'
");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$demande = $result->fetch_assoc();

if (!$demande) {
    die('Demande non trouvée ou paiement non effectué.');
}

// Générer un numéro de série unique
$numero_serie = strtoupper(uniqid('ACTE-'));
//Recupérer les détails selon le type d'acte
$details = '';
switch ($demande['type_acte']) {
    case 'naissance':
        $sql = $conn->prepare("SELECT nom_complet, sex, nom_pere, nom_mere, date_naissance, lieu_naissance FROM naissances WHERE demande_id = ?");
        $sql->bind_param('i', $id);
        $sql->execute();
        $res = $sql->get_result()->fetch_assoc();
        $details = "Nom complet: " .
            $res['nom_complet'] . "\nSexe: " .
            $res['sex'] . "\nNom pere: " .
            $res['nom_pere'] . "\nNom mere: " .
            $res['nom_mere'] . "\nDate naissance: " .
            $res['date_naissance'] . "\nLieu de Naissance: " .
            $res['lieu_naissance'];
        break;
    

    case 'mariage':
        $sql = $conn->prepare("SELECT nom_epoux, nom_epouse, temoin_epoux, temoin_epouse, date_mariage, lieu_mariage FROM mariages WHERE demande_id = ?");
        $sql->bind_param('i', $id);
        $sql->execute();
        $res = $sql->get_result()->fetch_assoc();
        $details = "Epoux: " .
            $res['nom_epoux'] . "\nEpouse: " .
            $res['nom_epouse'] . "\nTemoin epoux: " . 
            $res['temoin_epoux'] . "\nTemoin epouse: " .
            $res['temoin_epouse'] .  "\nDate mariage: " .
            $res['date_mariage'] . "\nLieu du mariage: " .
            $res['lieu_mariage'];
        break;

    case 'deces':
        $sql = $conn->prepare("SELECT nom_defunt, nom_pere_defunt, nom_mere_defunt, date_deces, lieu_deces FROM deces WHERE demande_id = ?");
        $sql->bind_param('i', $id);
        $sql->execute();
        $res = $sql->get_result()->fetch_assoc();
        $details = "Nom defunt: " .
            $res['nom_defunt'] . "\nPere Du Defunt: " . 
            $res['nom_pere_defunt'] . "\nMere Du defunt: " . 
            $res['nom_mere_defunt'] . "\nDate deces: " .
            $res['date_deces'] . "\nLieu du deces: " .
            $res['lieu_deces'];
        break;

    default:
        die('Type d\'acte inconnu.');
}
// Générer le PDF
$pdf = new FPDF();
$pdf->AddPage();

// Logo en haut
$pdf->Image('../public/image/logo.jpg', 10, 6, 30);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Republique de Cote d\'Ivoire', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Mairie de Brobo', 0, 1, 'C');

$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Acte Civil - ' . ucfirst($demande['type_acte']), 0, 1, 'C');

$pdf->Ln(10);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Numero Acte: ' . $numero_serie, 0, 1);
$pdf->MultiCell(0, 10, $details);

$pdf->Ln(20);
// Cachet ou signature en bas à droite
$pdf->Image('../public/image/sign.jpg', 150, 220, 40);

$pdf->SetY(-30);
$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(0, 10, 'Document genere automatiquement - Avec signature numerique', 0, 1, 'C');

// Sauvegarder le PDF dans un dossier
$chemin = "../pdfs/acte_$id.pdf";
$pdf->Output('F', $chemin);


echo "PDF stylisé généré avec succès.";

echo "<div class='mt-3'>";
echo "<a href='$chemin' class='btn btn-primary mt-4' download>Télécharger le PDF</a>";
echo "</div>";
