<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'mairie_brobo');

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../admin/admin_login.php');
    exit();
}

// Vérifie si l'ID est passé dans l'URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID manquant.");
}

$id = intval($_GET['id']);

// Récupération des détails de la demande d'acte
$demande_id = intval($_GET['id']); // Assurez-vous que l'ID est passé dans l'URL
$demandes_query = $conn->query("
       SELECT d.id, c.nom, c.prenom, d.type_acte, d.statut, d.date_demande, d.fichiers
       FROM demandes_actes d
       JOIN citoyens c ON d.citoyen_id = c.id
       WHERE d.id = $demande_id
   ");

if ($demandes_query) {
    $demandes = $demandes_query->fetch_assoc();
} else {
    $demandes = null; // Assurez-vous que la variable est définie
    echo "Erreur dans la requête SQL : " . $conn->error; // Affiche l'erreur SQL
}


// Récupération des détails de la déclaration
$declarations_query = $conn->query("
    SELECT decl.id, c.nom, c.prenom, decl.type_acte, decl.statut, decl.date_declaration, decl.fichiers
    FROM declarations decl
    JOIN citoyens c ON decl.citoyen_id = c.id
    WHERE decl.id = $id
");

// Affichage des fichiers joints
if ($demandes) {
    echo "<h4>Demande d'Acte</h4>";
    // ... autres détails ...
    echo "<p><strong>Fichiers joints :</strong></p>";
    echo "<ul>";
    if (!empty($demandes['fichiers'])) {
        $fichiers = explode(',', $demandes['fichiers']);
        foreach ($fichiers as $fichier) {
            echo "<li><a href='../uploads/" . htmlspecialchars($fichier) . "' target='_blank'>" . htmlspecialchars($fichier) . "</a></li>";
        }
    } else {
        echo "<li>Aucun fichier joint.</li>";
    }
    echo "</ul>";
}


if (!$declarations_query) {
    die("Erreur dans la requête SQL pour les déclarations : " . $conn->error);
}

$declarations = $declarations_query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Détails de la Demande / Déclaration</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Détails de la Demande / Déclaration</h2>
        <hr>

        <?php if ($demandes) : ?>
            <h4>Demande d'Acte</h4>
            <p><strong>ID :</strong> <?= htmlspecialchars($demandes['id']) ?></p>
            <p><strong>Nom :</strong> <?= htmlspecialchars($demandes['nom']) . ' ' . htmlspecialchars($demandes['prenom']) ?></p>
            <p><strong>Type d'Acte :</strong> <?= htmlspecialchars(ucfirst($demandes['type_acte'])) ?></p>
            <p><strong>Statut :</strong> <?= htmlspecialchars(ucfirst($demandes['statut'])) ?></p>
            <p><strong>Date de Demande :</strong> <?= date('d/m/Y', strtotime($demandes['date_demande'])) ?></p>
            <p><strong>Fichiers joints :</strong></p>
            <ul>
                <?php if ($demandes['fichiers']) : ?>
                    <?php $fichiers = explode(',', $demandes['fichiers']); ?>
                    <?php foreach ($fichiers as $fichier) : ?>
                        <li><a href="../uploads/<?= htmlspecialchars($fichier) ?>" target="_blank"><?= htmlspecialchars($fichier) ?></a></li>
                    <?php endforeach; ?>
                <?php else : ?>
                    <li>Aucun fichier joint.</li>
                <?php endif; ?>
            </ul>
        <?php else : ?>
            <p>Aucune demande d'acte trouvée pour cet ID.</p>
        <?php endif; ?>

        <?php if ($declarations) : ?>
            <h4>Déclaration</h4>
            <p><strong>ID :</strong> <?= htmlspecialchars($declarations['id']) ?></p>
            <p><strong>Nom :</strong> <?= htmlspecialchars($declarations['nom']) . ' ' . htmlspecialchars($declarations['prenom']) ?></p>
            <p><strong>Type d'Acte :</strong> <?= htmlspecialchars(ucfirst($declarations['type_acte'])) ?></p>
            <p><strong>Statut :</strong> <?= htmlspecialchars(ucfirst($declarations['statut'])) ?></p>
            <p><strong>Date de Déclaration :</strong> <?= date('d/m/Y', strtotime($declarations['date_declaration'])) ?></p>
            <p><strong>Fichiers joints :</strong></p>
            <ul>
                <?php if ($declarations['fichiers']) : ?>
                    <?php $fichiers = explode(',', $declarations['fichiers']); ?>
                    <?php foreach ($fichiers as $fichier) : ?>
                        <li><a href="../uploads/<?= htmlspecialchars($fichier) ?>" target="_blank"><?= htmlspecialchars($fichier) ?></a></li>
                    <?php endforeach; ?>
                <?php else : ?>
                    <li>Aucun fichier joint.</li>
                <?php endif; ?>
            </ul>
        <?php else : ?>
            <p>Aucune déclaration trouvée pour cet ID.</p>
        <?php endif; ?>

        <a href="admin_dashboard.php" class="btn btn-primary mt-3">Retour au Tableau de Bord</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>